# Santander
A new, enhanced File Manager for iOS devices

![Screenshot 2022-08-04 at 3 26 56 PM](https://user-images.githubusercontent.com/48022799/182846725-84790bea-e9ba-45a3-a2c2-ee6f2f7fdd4e.png)

Santander aims to enhance the experience of a file manager on an iOS device, using modern and familiar UI alongside new APIs.

# Notice
The project is still in beta, and there still quite a lot of bugs to fix & enhancements to make.
